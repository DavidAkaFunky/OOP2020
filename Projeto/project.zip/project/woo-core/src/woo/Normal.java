package woo;

public class Normal implements Status {
    
    public Normal(){ }

    @Override
    public String toString() {
        return "NORMAL";
    }

}
