package woo;

public interface Status {

    public String toString();
}
