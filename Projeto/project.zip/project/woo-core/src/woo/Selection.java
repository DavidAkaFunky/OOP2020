package woo;

public class Selection implements Status {
    
    public Selection(){ }

    @Override
    public String toString() {
        return "SELECTION";
    }
}
