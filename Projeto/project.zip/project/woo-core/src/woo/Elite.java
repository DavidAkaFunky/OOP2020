package woo;

public class Elite implements Status {
    
    public Elite(){ }

    @Override
    public String toString() {
        return "ELITE";
    }
}
